<head>
	
	
	<title>Flyhi Admin</title>
	
	<meta charset="utf-8">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="robots" content="index, follow">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Icons -->
	<link rel="shortcut icon" href="/favicon.ico">
	<link rel="apple-touch-icon" href="/apple-touch-icon.png">
	
	<!-- CSS Styles -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/screen.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/colors.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.muon.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.tipsy.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.wysiwyg.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.datatables.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.nyromodal.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.datepicker.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.fileinput.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.fullcalendar.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.visualize.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/admin/css/jquery.snippet.css">
	<!-- CSS Styles -->

	<!-- Google WebFonts -->
	<link href='http://fonts.googleapis.com/css?family=Droid+Sans+Mono|Open+Sans:400,400italic,700,700italic&amp;v2' rel='stylesheet' type='text/css'>  

        <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.2.min.js"></script>
        
	<!-- Modernizr adds classes to the <html> element which allow you to target specific browser functionality in your stylesheet -->
	<script src="<?php echo base_url(); ?>public/admin/js/libs/modernizr-1.7.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>public/ckeditor/ckeditor.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>public/admin/js/jquery.validate.js"></script>
        <script type="text/javascript">
	$(document).ready(function(){ // jQuery DOM ready function.
		$("form").validate();
	});
	</script>
        
