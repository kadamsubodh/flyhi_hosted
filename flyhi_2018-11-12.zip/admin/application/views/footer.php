<!-- Main Footer -->
<footer id="footer">


        <script src="<?php echo base_url(); ?>public/admin/js/libs/selectivizr.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.visualize.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.visualize.tooltip.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.tipsy.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.nyromodal.min.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.wysiwyg.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.datatables.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.datepicker.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.fileinput.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.fullcalendar.min.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.ui.totop.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.snippet.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/jquery/jquery.muonmenu.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/script.js"></script>
        <script src="<?php echo base_url(); ?>public/admin/js/login.js"></script>
        
   

</footer>
<!-- /Main Footer -->
